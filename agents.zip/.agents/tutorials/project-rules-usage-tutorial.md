# Hướng Dẫn Sử Dụng Bộ Quy Tắc Lập Trình (Project Rules)

Tài liệu này hướng dẫn cách sử dụng và kích hoạt các bộ quy tắc lập trình (Rules) trong dự án J2N để đảm bảo code được Agent (Antigravity) viết ra luôn đạt chuẩn hệ thống.

## 1. Giới Thiệu
Dự án J2N sử dụng hệ thống quy tắc phân tầng để tối ưu hóa việc hỗ trợ từ Agent. Các quy tắc được chia thành:
- **Basic Rules**: Quy tắc nền tảng cho mọi service.
- **Specialized Rules**: Quy tắc riêng cho từng giao thức giao tiếp (REST, gRPC, GraphQL).

## 2. Các Bộ Quy Tắc Hiện Có
Hệ thống rules nằm tại thư mục `.agents/rules/`:
- `j2n-basic-rules.md`: Quy tắc Java, DTO, Security, Service Layer (Mặc định luôn bật).
- `j2n-rest-rules.md`: Quy tắc chuẩn RESTful API và Swagger (Kích hoạt thủ công).
- `j2n-grpc-rules.md`: Quy tắc quản lý Proto và triển khai gRPC Server/Client (Kích hoạt thủ công).
- `j2n-graphql-rules.md`: Quy tắc Schema, Controller và BFF GraphQL (Kích hoạt thủ công).

## 3. Cách Sử Dụng

### 3.1. Quy tắc mặc định (Basic)
Bạn không cần làm gì cả. Mọi yêu cầu liên quan đến file Java trong dự án đều sẽ tự động tuân thủ theo `j2n-basic-rules.md`.

### 3.2. Kích hoạt quy tắc chuyên biệt
Khi làm việc với các service sử dụng REST, gRPC hoặc GraphQL, bạn cần @ nhắc đến file rule tương ứng để Agent áp dụng thêm các chuẩn nâng cao.

**Ví dụ câu lệnh (Prompts):**

- **Cho REST API:**
  > "Hãy tạo một Controller mới cho domain 'order' tuân thủ theo @j2n-rest-rules.md. Nhớ thêm đầy đủ Swagger annotations."

- **Cho gRPC:**
  > "Tôi vừa thêm `product.proto` vào `lib-srv`, hãy giúp tôi triển khai gRPC server cho nó trong `product-srv` dựa trên @j2n-grpc-rules.md."

- **Cho GraphQL:**
  > "Cập nhật Schema và Controller GraphQL cho tính năng khuyến mãi, áp dụng các chuẩn trong @j2n-graphql-rules.md."

## 4. Những Điểm Cần Lưu Ý
- **Tính ưu tiên**: Khi bạn nhắc đến một bộ quy tắc chuyên biệt, Agent sẽ kết hợp nó với bộ quy tắc Basic để tạo ra kết quả tốt nhất.
- **Workflow gRPC**: Nhớ chạy lệnh re-generate code (`mvn install` cho `lib-srv`) khi thay đổi file Proto trước khi yêu cầu Agent viết code Service.
- **Đồng bộ GraphQL**: Khi sửa Schema ở Server, hãy yêu cầu Agent cập nhật cả Document ở BFF để đảm bảo tính đồng bộ.

---
*Tài liệu này giúp bạn tương tác hiệu quả hơn với Agent trong dự án J2N.*
