# Hướng Dẫn Sử Dụng Workflow Tạo Postman Collection

Tài liệu này hướng dẫn cách sử dụng workflow `/j2n-generate-curl-workflow` để tự động tạo file Postman Collection JSON cho các API trong dự án J2N.

## 1. Giới Thiệu
Workflow `/j2n-generate-curl-workflow` giúp chuẩn hóa việc tạo tài liệu API. Thay vì viết tay các câu lệnh curl, workflow này hướng dẫn Agent quét các Controller, xác định endpoint, cấu trúc request/response và xuất ra file JSON có thể import trực tiếp vào Postman.

## 2. Cách Kích Hoạt Workflow
Bạn có thể yêu cầu Agent thực hiện thông qua slash command hoặc yêu cầu trực tiếp:

### Cách 1: Sử dụng Slash Command
Gõ trực tiếp trong khung chat:
`@Antigravity /j2n-generate-curl-workflow hãy tạo collection cho toàn bộ room-srv`

### Cách 2: Yêu cầu bằng ngôn ngữ tự nhiên
`Dựa vào workflow tạo curl, hãy giúp tôi quét các controller trong 'report-srv' và tạo file postman collection.`

## 3. Các Ví Dụ Câu Lệnh (Prompts)

Dưới đây là một số ví dụ thực tế bạn có thể dùng:

### Ví dụ 1: Tạo cho một Controller cụ thể
> "Hãy tạo Postman Collection cho `AssetController` trong `room-srv`. Tuân thủ workflow để đảm bảo có đầy đủ các header internal token và placeholder cho ID."

### Ví dụ 2: Tạo cho toàn bộ Service
> "Quét toàn bộ controller trong module `bff-srv` và tạo một file Postman Collection duy nhất. Nhớ sử dụng chuẩn header Bearer Token cho BFF."

### Ví dụ 3: Cập nhật Collection sau khi sửa API
> "Tôi vừa thêm endpoint mới vào `RoomController`. Hãy cập nhật file Postman Collection của `room-srv` theo đúng quy trình trong workflow."

## 4. Những Điểm Cần Lưu Ý
- **Header chuẩn**: Agent sẽ tự động cấu hình `X-Internal-Token` cho các service nội bộ và `Authorization: Bearer` cho `bff-srv`.
- **Quy tắc đặt tên**: Folder luôn có tiền tố `J2N-` (Ví dụ: `J2N-Room`). Tên API sẽ theo format `{METHOD} {PATH}`.
- **Placeholder**: Các tham số trên URL (path variables) sẽ được chuyển thành dạng `:variableName` (Ví dụ: `:roomId`) để Postman nhận diện.
- **Vị trí lưu**: Mặc định các file JSON sẽ được lưu tại thư mục `document/` trong thư mục gốc của project (Ví dụ: `document/room-srv-api-collection.json`).

---
*Tài liệu này thuộc hệ thống hỗ trợ Agent J2N.*
