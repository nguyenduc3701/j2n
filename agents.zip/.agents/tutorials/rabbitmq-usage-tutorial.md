# Hướng Dẫn Sử Dụng RabbitMQ Workflow

Tài liệu này hướng dẫn cách sử dụng workflow `/j2n-rabbitmq-workflow` để triển khai hệ thống tin nhắn (RabbitMQ) trong dự án J2N một cách chuẩn xác và đồng nhất.

## 1. Giới Thiệu
Workflow `/j2n-rabbitmq-workflow` được thiết kế để giúp bạn (và Agent) tạo ra các thành phần Messaging (Consumer, Publisher, Event DTO, Config) tuân thủ đúng cấu trúc của dự án J2N, đặc biệt là lấy `report-srv` làm chuẩn.

## 2. Cách Kích Hoạt Workflow
Bạn có thể yêu cầu Agent thực hiện bằng cách sử dụng câu lệnh trực tiếp hoặc nhắc đến workflow:

### Cách 1: Sử dụng Slash Command
Bạn có thể gõ trực tiếp trong khung chat:
`@Antigravity /j2n-rabbitmq-workflow hãy tạo một consumer cho domain 'order' trong service 'payment-srv'`

### Cách 2: Yêu cầu bằng ngôn ngữ tự nhiên
`Dựa vào workflow RabbitMQ, hãy viết code cho tôi để nhận sự kiện 'user.deleted' trong 'report-srv'`

## 3. Các Ví Dụ Câu Lệnh (Prompts)

Dưới đây là một số ví dụ thực tế bạn có thể dùng:

### Ví dụ 1: Tạo Consumer mới (Chỉ nhận tin và gọi Service)
> "Hãy tạo một RabbitMQ Consumer cho service `inventory-srv` để nhận sự kiện `payment.confirmed`. Lưu ý tuân thủ workflow: Consumer chỉ gọi tới service layer, không để logic ở đó."

### Ví dụ 2: Tạo Publisher để gửi tin nhắn
> "Tôi muốn tạo một Publisher trong `order-srv` để gửi sự kiện `order.created` mỗi khi có đơn hàng mới. Hãy thiết lập cả Constants và Config theo chuẩn J2N."

### Ví dụ 3: Triển khai toàn bộ cấu trúc Messaging cho một Domain mới
> "Thiết lập cấu trúc RabbitMQ hoàn chỉnh cho domain `promotion` trong `product-srv`. Bao gồm: Constant, Event DTO, Config và một Consumer mẫu."

## 4. Những Điểm Cần Lưu Ý
- **Base Config**: Agent sẽ tự động kiểm tra và thêm `@Import({ BaseRabbitConfig.class, RabbitTemplateConfig.class })` vào Application class nếu chưa có.
- **Manual Ack**: Tất cả các Consumer mặc định sử dụng `channel.basicAck` và `channel.basicNack` để đảm bảo tin nhắn không bị mất.
- **Tách biệt Logic**: Consumer **CHỈ** làm nhiệm vụ nhận tin và gọi Service. Mọi logic xử lý nghiệp vụ phải nằm trong file Service.

---
*Tài liệu này thuộc hệ thống hỗ trợ Agent J2N.*
