---
trigger: always_on
glob: "**/*.{java,ts,tsx,js,jsx,json,md}"
description: "Quy tắc lập trình chung và ngôn ngữ cho dự án J2N"
---

# General Programming Rules (J2N)

Tài liệu này định nghĩa các quy tắc chung và ngôn ngữ bắt buộc phải tuân thủ trong toàn bộ dự án J2N (bao gồm cả Backend Java và Frontend Next.js/TypeScript).

## 1. Ngôn Ngữ Phát Triển (Programming Language & English First)

1. **Bắt buộc sử dụng Tiếng Anh**:
   - Toàn bộ mã nguồn, bao gồm tên biến (variables), tên hàm/phương thức (functions/methods), tên lớp/giao diện (classes/interfaces), và ghi chú trong code (comments), phải được đặt tên và viết hoàn toàn bằng **tiếng Anh**.
   - Các tài liệu đi kèm trực tiếp trong code như mô tả API (Swagger descriptions, OpenAPI specs, GraphQL schemas) và các thông báo lỗi/validation mặc định của hệ thống cũng phải sử dụng tiếng Anh.
2. **Ngoại lệ về Đa Ngôn Ngữ (i18n)**:
   - Các giá trị dịch thuật trong các file JSON đa ngôn ngữ (`common.json`) được viết theo ngôn ngữ tương ứng, nhưng bản thân khóa dịch thuật (translation key) bắt buộc phải là tiếng Anh hoặc camelCase tiếng Anh (ví dụ: `rooms`, `userManagement.title`).

## 2. Định Dạng Dữ Liệu & API (Data Format Standards)

1. **Nhất quán chuẩn snake_case**:
   - Toàn bộ dữ liệu trao đổi giữa Client, BFF, và các Microservices thông qua REST API/BFF API phải sử dụng định dạng **snake_case** cho các keys (ví dụ: `user_name`, `start_date`, `role_id`).
   - Ở phía Java: Dùng `@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)` cho tất cả DTOs.
   - Ở phía TypeScript: Các interface mô tả DTOs hoặc payload cũng phải khai báo chính xác các keys ở dạng snake_case để tránh lỗi mismatch dữ liệu.

## 3. Quản Lý Chất Lượng & Clean Code

1. **Ngăn chặn code rác (No Commented-out Code)**:
   - Tuyệt đối không lưu lại các đoạn code thừa, code debug cũ hoặc code bị comment vô thời hạn trong file mã nguồn khi commit.
2. **Tách nhỏ method/function (Single Responsibility & Decomposition)**:
   - Luôn ưu tiên tách nhỏ các method/function dài thành các helper method/function con dựa trên chức năng cụ thể.
   - Tránh viết các method/function quá dài, phức tạp hoặc thực hiện quá nhiều nhiệm vụ cùng một lúc để nâng cao tính tái sử dụng và giúp viết unit test dễ dàng hơn.
3. **Cập nhật Unit Test**:
   - Khi chỉnh sửa hoặc viết mới bất cứ logic nghiệp vụ nào (ở cả Backend và Frontend), bắt buộc phải cập nhật hoặc viết thêm các unit tests tương ứng để đảm bảo tính ổn định và duy trì độ bao phủ kiểm thử cao.

