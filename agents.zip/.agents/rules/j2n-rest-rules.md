---
trigger: manual
glob: "backend/**/*.java"
description: "Quy tắc phát triển RESTful API cho dự án J2N"
---

# RESTful API Development Rules

1. **API Documentation (Swagger)**:
    - Sử dụng bộ annotation `@J2NApiResponses`, `@J2NApiResponse`, và `@J2NApiExample` (trong package `com.example.j2n.swagger.annotation`) cho tất cả các Controller methods.
    - Cung cấp ví dụ (examples) cho cả thành công và lỗi bằng cách tham chiếu đến `BaseMessageEnum` hoặc `MessageEnum` của module.

2. **Cấu trúc Controller**:
    - Các controller method phải luôn trả về `ResponseEntity<BaseResponse<T>>`.
    - Sử dụng `@Valid` kết hợp với `@RequestBody` cho các đối tượng Input DTO để đảm bảo dữ liệu đầu vào hợp lệ.

3. **HTTP Methods & Path Mapping**:
    - Tuân thủ chuẩn REST: `GET` cho lấy dữ liệu, `POST` cho tạo mới hoặc tìm kiếm phức tạp (Search), `PUT` cho cập nhật, `DELETE` cho xóa.
    - **Lưu ý về Update**: Luôn ưu tiên sử dụng `PUT` cho tất cả các thao tác cập nhật dữ liệu. **Tránh sử dụng `PATCH`** để đảm bảo tính nhất quán và đơn giản hóa logic xử lý.
    - Path mapping nên rõ ràng và phản ánh đúng tài nguyên đang thao tác.

4. **DTO, Request & Response Standards**:
    - **Documentation (Swagger)**: Luôn sử dụng annotation `@Schema` (từ `io.swagger.v3.oas.annotations.media.Schema`) cho tất cả các field. Cung cấp đầy đủ `description`, `example`, `requiredMode` và `format` (nếu cần).
    - **Validation**: Sử dụng các annotation của Jakarta Bean Validation (`@NotBlank`, `@Email`, `@Size`, `@Min`, `@Max`, v.v.) để ràng buộc dữ liệu.
    - **Validation Messages**: Tất cả các validation annotation phải đi kèm với thuộc tính `message` rõ ràng (ví dụ: `@NotBlank(message = "Username is required")`).
    - **Tính nhất quán**: Đảm bảo `@Schema(requiredMode = ...)` phải nhất quán với các validation annotation (ví dụ: nếu có `@NotBlank` thì `requiredMode` phải là `REQUIRED`).
