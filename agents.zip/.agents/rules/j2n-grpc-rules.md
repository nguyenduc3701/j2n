---
trigger: manual
glob: "backend/**/*.java, backend/**/*.proto"
description: "Quy tắc phát triển gRPC cho dự án J2N"
---

# gRPC Development Rules

1. **Quản lý Proto Files (Schema tập trung)**:
    - Tất cả các file `.proto` phải được lưu trữ tại `backend/lib-srv/src/main/proto`.
    - Sử dụng `package com.example.j2n.lib.proto;` và các option chuẩn:
      ```proto
      option java_multiple_files = true;
      option java_package = "com.example.j2n.lib.proto";
      ```
    - **Base Response**: Luôn sử dụng `BaseProtoResponse` (chứa `code`, `message`, `google.protobuf.Struct data`) để đồng bộ với chuẩn REST `BaseResponse`.

2. **Triển khai gRPC Server (Provider)**:
    - Sử dụng annotation `@GrpcService` của `grpc-spring-boot-starter`.
    - Kế thừa class base được generate (ví dụ: `XxxServiceGrpc.XxxServiceImplBase`).
    - **Mapper**: Sử dụng `GrpcResponseFactory.of(responseObserver, baseResponse, objectMapper)` để tự động chuyển đổi từ POJO sang Protobuf Message.
    - Luôn bọc phương thức bằng `@LogAround`.

3. **Triển khai gRPC Client (Consumer)**:
    - Sử dụng `GrpcFactory` để quản lý `ManagedChannel` và `BlockingStub`.
    - **Security Propagation**: Bắt buộc truyền tải Metadata (Headers) gồm `x-user-id`, `x-role-id`, và `x-internal-token`.
    - Đối với Gateway (Reactive): Lời gọi gRPC blocking phải được bọc trong `Mono.fromCallable()`.

4. **Khi chỉnh sửa file .proto (Workflow)**:
    - **Bước 1: Re-generate**: Sau khi sửa file `.proto` trong `lib-srv`, phải chạy lệnh `./mvnw clean install` tại thư mục `backend/lib-srv` để generate lại các Java class.
    - **Bước 2: Cập nhật Service**: 
        - Phía **Server**: Cập nhật các phương thức trong class kế thừa `ServiceImplBase` nếu có thay đổi tham số hoặc tên method.
        - Phía **Client**: Kiểm tra lại các lời gọi stub. Nếu dùng `DynamicGrpcInvoker`, hãy đảm bảo tên method truyền vào khớp với tên trong proto (không phân biệt hoa thường).
    - **Bước 3: Tương thích ngược**: Tránh thay đổi `field number` của các trường cũ. Nếu cần bỏ trường, hãy dùng tag `reserved`.

5. **Cấu hình**:
    - Địa chỉ service dạng: `grpc://<host>:<port>`.
    - Cổng mặc định cho gRPC server thường là `9091` (trong khi REST là `808x`).
