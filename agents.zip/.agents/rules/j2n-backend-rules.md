---
trigger: always_on
description: "Quy tắc lập trình Java cơ bản cho dự án J2N"
---

# Java Development Rules

1. **Ưu tiên sử dụng `lib-srv`**: Khi viết code Java, luôn ưu tiên sử dụng các class, phương thức và cấu trúc đã được định nghĩa sẵn trong module `backend/lib-srv`.
   - **Utility Classes**: Sử dụng `ResponseFactory`, `ValidationUtils`, `PageUtil`, `RedisUtil`, v.v. thay vì tự viết lại các logic tương tự.
   - **Base DTOs**: Luôn kế thừa hoặc sử dụng các class base như `BaseRequest`, `BaseResponse`, `PagingRequest`, `PagingResponse`.
   - **Exception Handling**: Sử dụng các custom exceptions trong package `com.example.j2n.exception` (như `BaseServiceException`, `DataNotFoundException`, v.v.).
   - **Constants & Enums**: Kiểm tra và sử dụng các hằng số trong `CommonConst` hoặc các enums dùng chung.
   - **Messaging**: Sử dụng `BaseRabbitConfig` và `BaseEventPublisher` cho các tác vụ liên quan đến RabbitMQ.

2. **Tính nhất quán**: Việc sử dụng `lib-srv` giúp đảm bảo tính nhất quán về logic xử lý, định dạng response và quản lý lỗi trong toàn bộ hệ thống microservices.

3. **DTO & JSON Standards**:
   - Sử dụng `@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)` cho tất cả Request/Response DTO để đảm bảo chuẩn snake_case.
   - **Không trả về Entity**: Các API tuyệt đối không trả về Entity trực tiếp. Luôn định nghĩa lớp response riêng (đặt trong package `service/response`) và trả về dưới dạng snake_case.
   - Ưu tiên sử dụng Lombok annotations: `@Data`, `@Builder`, `@NoArgsConstructor`, và `@AllArgsConstructor`.
   - **Documentation & Validation**: Luôn sử dụng đầy đủ `@Schema` (Swagger) và các Jakarta Bean Validation annotations (như `@NotBlank`, `@Email`, `@Size`,...) kèm theo `message` cụ thể cho mỗi field (tham khảo chi tiết tại `j2n-rest-rules.md`).
   - Sử dụng `Optional<T>` cho các trường filter trong Search Request DTO.

4. **Security & Authentication**:
   - Sử dụng `PasswordUtil` cho mật khẩu và `JwtGeneralUtil` cho token JWT.
   - Quản lý session/refresh token qua `RedisUtil` với prefix từ `CommonConst`.

5. **Cấu trúc Service Layer**:
   - Sử dụng `@LogAround` cho các phương thức service để tự động log xử lý.
   - Tách logic validation thành các phương thức private/protected riêng trong service.

6. **Unit Testing**:
   - **Bắt buộc cập nhật**: Khi sửa đổi hoặc thêm mới logic trong Controller, Service, hoặc Utility, luôn phải đi kèm với việc cập nhật hoặc viết mới Unit Test tương ứng.
   - **Vị trí**: File test phải được đặt trong thư mục `src/test/java` với cấu trúc package tương ứng với file source.
   - **Công cụ**: Sử dụng JUnit 5 và Mockito. Ưu tiên sử dụng `@ExtendWith(MockitoExtension.class)` thay vì khởi tạo mock thủ công.
   - **Chất lượng**: Đảm bảo bao phủ (**coverage 100%**) cho tất cả các trường hợp biên (edge cases) và logic nghiệp vụ.

7. **Ngôn ngữ**: Tất cả code, bao gồm tên biến, tên class, comment, description và example trong Swagger documentation, cũng như validation message, phải sử dụng tiếng Anh.
