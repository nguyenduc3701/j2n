---
trigger: manual
glob: "backend/**/*.java, backend/**/*.graphqls, backend/**/*.graphql"
description: "Quy tắc phát triển GraphQL cho dự án J2N"
---

# GraphQL Development Rules

1. **Quản lý Schema (Server Side)**:
    - File schema `.graphqls` phải được đặt tại `src/main/resources/graphql/`.
    - **Naming Convention**: Sử dụng `Query` cho các thao tác đọc và `Mutation` cho các thao tác thay đổi dữ liệu.
    - **Response Wrapper**: Luôn bọc dữ liệu trả về trong một Type có cấu trúc gồm `code`, `message`, và `data` để đồng bộ với chuẩn `BaseResponse`.
      ```graphql
      type XxxResponse {
        code: String
        message: String
        data: Xxx
      }
      ```

2. **Triển khai Controller (Server Side)**:
    - Sử dụng các annotation `@QueryMapping` và `@MutationMapping` (tên method hoặc thuộc tính `name` phải khớp với schema).
    - Sử dụng `@Argument` để nhận tham số từ client.
    - **Validation**: Sử dụng `@Valid` kết hợp với `@Argument` cho các đối tượng Input DTO.

3. **Quản lý GraphQL Documents (Client/BFF Side)**:
    - Các file định nghĩa operation `.graphql` phải được đặt tại `src/main/resources/graphql-documents/` của service gọi (ví dụ: `bff-srv`).
    - **Operation Naming**: Các operation nên có tiền tố `Op_` để dễ phân biệt (ví dụ: `query Op_getProductById`).
    - Chỉ request các field thực sự cần thiết để tối ưu hóa hiệu năng.

4. **Triển khai GraphQL Client (BFF Side)**:
    - Sử dụng `GraphQLFactory` để thực thi các lệnh.
    - Định nghĩa hằng số cho tên file document (không bao gồm phần mở rộng `.graphql`).
    - Sử dụng `ParameterizedTypeReference` để deserialize kết quả trả về một cách chính xác.

5. **Quy trình thay đổi (Workflow)**:
    - **Tính đồng bộ**: Khi thêm/sửa field trong `.graphqls` ở phía Server, phải cập nhật file `.graphql` tương ứng ở phía BFF để có thể lấy được dữ liệu mới.
    - **Kiểm tra Mapping**: Đảm bảo tên các field trong Java DTO khớp hoàn toàn với tên field trong GraphQL Schema (hoặc sử dụng `@JsonProperty` nếu cần).
