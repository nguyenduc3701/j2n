---
trigger: always_on
description: "Quy tắc phát triển Frontend cơ bản cho dự án J2N"
---

# Frontend Development Rules

Tài liệu này định nghĩa các quy tắc bắt buộc phải tuân thủ khi phát triển, chỉnh sửa, hoặc bổ sung mã nguồn frontend (Next.js, React, TypeScript) trong thư mục `frontend/` thuộc dự án J2N.

## 1. Cấu Trúc Dự Án & Monorepo Standards

1. **Monorepo Workspace Alignment**:
   - **Apps**: Viết mã nguồn nghiệp vụ của các trang và ứng dụng độc lập trong thư mục `apps/web/[app-name]`. Không viết logic nghiệp vụ trực tiếp trong thư mục `packages/`.
   - **Packages**: Các UI component chung, helper giao tiếp mạng, cấu hình hoặc global state dùng chung PHẢI được định nghĩa trong `packages/` (`@repo/ui`, `@repo/network`, `@repo/store`).
2. **Import Path Aliasing**:
   - Luôn sử dụng path aliases được định nghĩa trong `tsconfig.json` khi import các module dùng chung.
   - **Không** sử dụng tương đối sâu (ví dụ: `../../../../packages/ui/...`).
   - _Đúng_: `import J2NButton from "@repo/components/atoms/J2NButton";`
   - _Sai_: `import J2NButton from "../../../../packages/ui/src/components/atoms/J2NButton";`

## 2. Quy Tắc Định Dạng API & JSON (BFF Standards)

1. **Chuẩn snake_case**:
   - Tất cả dữ liệu JSON gửi lên BFF (Request payload) và nhận về từ BFF (Response data) phải sử dụng định dạng **snake_case** cho các keys (ví dụ: `user_name`, `role_id`, `start_date`, `end_date`).
   - Các interfaces/types định nghĩa trong frontend phản ánh cấu trúc API DTO phải tuân thủ đúng định dạng snake_case này.
2. **API Service Encapsulation**:
   - Không gọi trực tiếp hàm `request` của `@repo/network` ở trong các Component hoặc Page.
   - Tất cả các API call phải được định nghĩa tập trung trong thư mục `services/` của app (ví dụ: `apps/web/management/services/userServices.ts`) dưới dạng các object chứa các phương thức bất đồng bộ.
3. **Authentication & Authorization Headers**:
   - Phiên đăng nhập và JWT Token được xử lý tự động bởi custom client của `@repo/network`. Tuyệt đối không tự viết logic chèn tay Bearer Token vào header trừ trường hợp đặc biệt được chỉ định.
   - Tuyệt đối không can thiệp thủ công vào luồng silent refresh token (đồng bộ qua header `x-new-access-token`).
4. **Bắt buộc ưu tiên sử dụng React Query (Query/Mutation)**:
   - **BẮT BUỘC**: Sử dụng `@tanstack/react-query` (thông qua package dùng chung `@repo/query` tại `frontend/packages/query`) để quản lý toàn bộ trạng thái bất đồng bộ (async state), caching, refetching và tương tác với các API call từ service.
   - **CẢNH BÁO CHO AI**: Ngay cả khi mã nguồn mẫu (reference code như `rooms/page.tsx`, `AssetTab.tsx`, v.v.) sử dụng `useEffect` kết hợp với `useState` thủ công để fetch dữ liệu, bạn **VẪN PHẢI** sử dụng `@tanstack/react-query` cho các tính năng mới hoặc chỉnh sửa lớn để duy trì kiến trúc chuẩn của dự án. Không copy cấu trúc `useEffect` fetch dữ liệu thủ công từ code cũ.
   - Hạn chế sử dụng `useEffect` kết hợp với local state (`useState`) để fetch và quản lý dữ liệu bất đồng bộ từ API trừ trường hợp thực sự cần thiết hoặc các logic đơn giản không cần caching/global state.

## 3. Styling & UI Design System (Mantine + Tailwind CSS v4)

1. **Về Thư Viện Core**:
   - Ưu tiên tối đa việc tái sử dụng các components nguyên tử (**Atoms**) và phân tử (**Molecules**) đã được xây dựng sẵn trong `@repo/ui/src/components`.
   - Nếu cần tạo component mới, sử dụng Mantine UI làm nền tảng, bọc bên ngoài và định dạng style bằng Tailwind CSS v4.
2. **Về Ghi Đè Style (Override Style)**:
   - Khi tùy biến hoặc override style của Mantine, sử dụng các utility classes của Tailwind với tiền tố `!` (important) để đảm bảo độ ưu tiên CSS (ví dụ: `className="!bg-j2n-mauve-500 !text-j2n-sand-50"`).
3. **Về Hệ Màu Theme**:
   - Chỉ sử dụng các biến màu hệ thống đã được cấu hình trong `@theme` tại `globals.css` để thiết kế giao diện (ví dụ: `bg-j2n-mauve-500`, `text-j2n-sand-light-300`, `bg-j2n-grape-deep-500`).
   - Không sử dụng mã màu Hex tùy tiện (như `#ff0000`, `#0000ff`) trực tiếp trong class hoặc style của component.
4. **Về Hiệu Ứng (Animations)**:
   - Các hiệu ứng chuyển động, hiển thị trang, chuyển tab phải sử dụng Framer Motion được bọc sẵn trong `@repo/components/atoms/J2NMotionTransition/*` (như `J2NMotionFade`, `J2NMotionScale`) để đảm bảo tính mượt mà và nhất quán.

## 4. Quy Tắc Dịch Thuật & Đa Ngôn Ngữ (i18n)

1. **Cấm Hardcode Chuỗi Text Tĩnh & Ưu tiên J2NTransText**:
   - Không viết trực tiếp các chuỗi text hiển thị (như "Quản lý phòng", "Đăng nhập", "User Profile") vào mã nguồn JSX/TSX.
   - Tất cả các chuỗi text hiển thị tĩnh bắt buộc phải thông qua hook `useTranslation()` (từ `@repo/ui/src/providers`) hoặc các components dịch chuyên dụng như `<TransTitle />`, `<J2NTransText />`.
   - **Ưu tiên sử dụng `<J2NTransText />`**: Khi hiển thị văn bản dịch, luôn ưu tiên sử dụng component `<J2NTransText />` (được import từ `@repo/components/atoms/J2NTransText`) thay vì trực tiếp sử dụng hook `useTranslation()` và hàm `t()` bất cứ khi nào phù hợp, nhằm đảm bảo tính nhất quán và tận dụng các props styling từ Mantine `Text`.
2. **Vị Trí Lưu File Locale & Đồng Bộ Hóa**:
   - Mọi từ khóa dịch thuật (translation keys) phải được lưu tại `packages/ui/src/public/locales/[locale]/common.json`.
   - **Bắt buộc**: Khi thêm mới bất kỳ từ khóa (keyword) dịch thuật nào, bạn **phải tạo đồng thời** từ khóa đó trong tất cả các locale được hỗ trợ ở thư mục `packages/ui/src/public/locales` (hiện tại bao gồm: `cn`, `en`, `jp`, `kr`, `vi`). Việc này đảm bảo không bị thiếu dịch thuật ở bất kỳ ngôn ngữ nào.
3. **Chuẩn Khai Báo Import**:
   - Khi import các file JSON locale tĩnh trong các provider, luôn sử dụng cú pháp ES import có **Import Attributes**:
     ```typescript
     import enCommon from "../public/locales/en/common.json" with { type: "json" };
     ```

## 5. State Management & Hydration Safe

1. **Zustand Persist với Cookie**:
   - Mọi thông tin cần lưu trữ lâu dài (JWT token, thông tin user hiện tại, language) phải được cấu hình lưu vào Cookie thông qua custom `cookieStorage` được định nghĩa trong `@repo/store` để đảm bảo an toàn cho Hydration và hỗ trợ Server Side Rendering (SSR).
2. **Hydration Mismatch Prevention**:
   - Đối với các component hiển thị thông tin thay đổi theo Client-side state hoặc phụ thuộc vào Window API, phải đảm bảo các component đó được kiểm soát mount hoàn tất trước khi render thông tin động, hoặc sử dụng cơ chế `"use client"` và kiểm tra biến `mounted` của React.

## 6. Ngôn Ngữ Lập Trình & Tài Liệu

1. **Ngôn Ngữ Viết Code**:
   - Toàn bộ mã nguồn, bao gồm tên biến, tên component, tên file, comment trong code, và các types/interfaces, phải sử dụng **tiếng Anh**.
   - Các keys trong file JSON dịch thuật có thể sử dụng các ngôn ngữ tương ứng, nhưng key chính (translation key) bắt buộc phải là tiếng Anh hoặc định dạng camelCase tiếng Anh (ví dụ: `rooms`, `userManagement`, `loginScreen.title`).
