---
description: Quy trình Tạo Postman Collection cho Service
---

# Quy trình Tạo Postman Collection cho Service (J2N)

Quy trình này hướng dẫn cách tạo file Postman Collection dạng JSON cho các API của service, giúp import vào Postman dễ dàng dưới dạng một Folder duy nhất.

## Cấu trúc Header chuẩn

### 1. Dành cho Internal Services (room-srv, report-srv, v.v.)
- `Content-Type: application/json`
- `X-Internal-Token: {{internalToken}}`
- `X-User-Id: 1`
- `X-User-Name: admin`
- `X-Role-Id: 1`

### 2. Dành cho BFF Service (bff-srv)
- `Content-Type: application/json`
- `Authorization: Bearer {{authToken}}`

## Quy tắc đặt tên

1. **Tên Folder:** `J2N-[Service Name]` (Ví dụ: `J2N-Room`, `J2N-Report`). Tất cả API phải nằm trực tiếp trong folder này, không chia thêm folder con.
2. **Tên API (Request Name):** `{METHOD} {PATH}`.
    - Các Path Variable (như ID) phải được chuyển sang dạng placeholder với dấu `:`.
    - Ví dụ: `GET /rooms/:roomId`, `POST /room/assets/:assetId`.

## Các bước thực hiện

### 1. Phân tích Controller / Service
- Đọc file mục tiêu (Controller, GrpcService).
- Xác định HTTP Method, Path, và cấu trúc DTO (Request Body).
- Tìm file `application.properties` hoặc `application.yml` để xác định `server.port`.

### 2. Tạo nội dung JSON (Postman Collection v2.1.0)
Sử dụng template sau để tạo file:

```json
{
    "info": {
        "name": "J2N-[Service Name] Collection",
        "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
    },
    "item": [
        {
            "name": "J2N-[Service Name]",
            "item": [
                {
                    "name": "METHOD /path/to/resource",
                    "request": {
                        "method": "METHOD",
                        "header": [
                            { "key": "Content-Type", "value": "application/json" },
                            { "key": "X-Internal-Token", "value": "{{internalToken}}" },
                            { "key": "X-User-Id", "value": "1" },
                            { "key": "X-User-Name", "value": "admin" },
                            { "key": "X-Role-Id", "value": "1" }
                        ],
                        "body": {
                            "mode": "raw",
                            "raw": "{ ... JSON BODY ... }",
                            "options": { "raw": { "language": "json" } }
                        },
                        "url": {
                            "raw": "http://localhost:PORT/path/to/resource",
                            "protocol": "http",
                            "host": ["localhost"],
                            "port": "PORT",
                            "path": ["path", "to", "resource"],
                            "query": []
                        }
                    }
                }
            ]
        }
    ]
}
```

### 3. Xuất file kết quả
- Lưu dưới dạng file `.json`.
- Vị trí lưu: `document/<service-name>-api-collection.json`.

## Ví dụ kết quả (Room Service)

**Tên file:** `room-srv-api-collection.json`
**Tên Folder:** `J2N-Room`
**Danh sách API:**
- `POST /rooms/search`
- `GET /rooms/:roomId`
- `POST /rooms/:roomId`
- `POST /rooms/:roomId/fees`
- `DELETE /room/assets/:assetId`
