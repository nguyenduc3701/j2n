---
description: Quy trình Thay đổi Cấu trúc Database
---

# Quy trình Thay đổi Cấu trúc Database (DB Schema Change)

Hướng dẫn này cung cấp các bước chuẩn để thêm/sửa/xóa cột trong database, đảm bảo tính nhất quán giữa các microservices và các bảng clone (chế độ Read-only cache).

## 1. Xác định phạm vi ảnh hưởng

Trước khi thực hiện, hãy kiểm tra xem bảng này có "clone" ở các service khác không.

- **Bảng chính (Source of Truth):** Thường nằm trong `scripts/{service}-db/`.
- **Bảng Clone (Read-only cache):** Thường có tên `product_info` hoặc tương tự ở `order-db`, `payment-db`.

## 2. Cập nhật SQL Scripts

1. **Sửa file SQL gốc:** Cập nhật file `.sql` tương ứng trong thư mục `scripts/`.
2. **Sửa file SQL clone:** Nếu thông tin cần thiết cho Order/Payment, hãy cập nhật các file SQL clone tương ứng.
   - Ví dụ: `scripts/order-db/02_create_product_info_table.sql`.
3. **Tạo Script Migration (nếu cần):** Nếu đang phát triển trên DB đã có dữ liệu, hãy tạo lệnh `ALTER TABLE` để chạy thủ công hoặc qua migration tool.
4. **Cập nhật Local DB:** Chạy lệnh `./scripts/rebuild_db_local.sh` để drop và tạo lại schema mới cho môi trường local (chỉ dùng khi DB local chưa có data quan trọng).

## 3. Cập nhật Java Entities

Thực hiện cập nhật các Java Entity class để khớp với cấu trúc DB mới.

- **Main Service:** Cập nhật `@Entity` class (ví dụ: `ProductEntity.java`).
- **Consumer Services:** Cập nhật các bảng clone (ví dụ: `ProductInfoEntity.java` trong `order-srv` và `payment-srv`).
- **Quy tắc:** Luôn sử dụng `@Column(name = "snake_case")` và Lombok.

## 4. Cập nhật DTO & API

1. **Request DTO:** Nếu cột mới được truyền từ client (ví dụ: `ProductRequest`).
2. **Response DTO:** Nếu cột mới cần trả về trong API (ví dụ: `ProductResponse`).
3. **Cập nhật Mapping:** Kiểm tra các method dùng `Builder` hoặc Setter để map từ Entity sang DTO và ngược lại (ví dụ trong Service/Controller) để gán thêm field này.
4. **Quy tắc:** Tuân thủ `PropertyNamingStrategies.SnakeCaseStrategy`.

## 5. Đồng bộ hóa dữ liệu (Messaging)

Đây là bước quan trọng nhất để dữ liệu ở bảng clone được cập nhật tự động.

1. **Cập nhật Event DTO:** Thêm trường mới vào các class Event dùng chung/copy (ví dụ: `ProductCreatedEvent`, `ProductUpdatedEvent`).
2. **Cập nhật Publisher:** Tại Service gốc, gán giá trị mới vào Event trước khi gửi tới RabbitMQ.
3. **Cập nhật Consumer:** Tại các Service nhận (Order, Payment), cập nhật logic lưu trữ để lưu trường mới vào DB local.

## 6. Kiểm tra và Verify

1. **Build Project:** Chạy `mvn clean install` để đảm bảo không lỗi compile.
2. **Kiểm tra Mapping:** Đảm bảo dữ liệu từ Request -> Entity -> DB và DB -> Entity -> Response hoạt động đúng.
3. **Kiểm tra Sync:** Tạo/Cập nhật dữ liệu ở Service gốc và kiểm tra xem bảng clone ở các Service khác có nhận được dữ liệu mới không.
4. **Cập nhật Tests:** Cập nhật các Unit Tests, Integration Tests bị ảnh hưởng bởi việc thêm cột mới (nhất là các đoạn tạo mock data).

---

> [!IMPORTANT]
> Nếu bảng clone nằm ở nhiều service, hãy đảm bảo bạn đã cập nhật Event DTO ở **tất cả** các service đó để tránh lỗi `Unknown Property` khi Jackson deserialize message.
