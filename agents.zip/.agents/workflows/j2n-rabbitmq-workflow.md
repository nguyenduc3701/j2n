---
description: Hướng dẫn quy trình chuẩn để triển khai RabbitMQ Messaging (Consumers & Publishers) cho các service trong dự án J2N, dựa trên cấu trúc mẫu của `report-srv`.
---

# J2N Message Queue Workflow

**Description**: Hướng dẫn quy trình chuẩn để triển khai RabbitMQ Messaging (Consumers & Publishers) cho các service trong dự án J2N, dựa trên cấu trúc mẫu của `report-srv`.

This workflow provides a standardized process for implementing RabbitMQ messaging (Consumers and Publishers) in the J2N project, based on the pattern used in `report-srv`.

## Prerequisites

Ensure your service has the following:

1.  `lib-srv` dependency in `pom.xml`.
2.  `@Import({ BaseRabbitConfig.class, RabbitTemplateConfig.class })` in your main Application class.

## Workflow Steps

### 1. Create Package Structure

Under the service's base package, create the following structure for each domain (e.g., `payment`, `product`, `user`):
`com.example.j2n.[service_name].messaging.[domain].[config|constant|consumer|event|publisher]`

### 2. Define Constants

Create a class `[Domain]EventConstants.java` in the `constant` package to store Exchange, Queue, and Routing Key names.

```java
package com.example.j2n.[service_name].messaging.[domain].constant;

import lombok.Data;

@Data
public class [Domain]EventConstants {
    public static final String EXCHANGE_[DOMAIN] = "[domain].exchange";

    // Queue names (unique per service-queue pair)
    public static final String QUEUE_[SERVICE]_[EVENT] = "[service].[domain].[event].queue";

    // Routing keys
    public static final String RK_[EVENT] = "[domain].[event]";
    public static final String RK_[DOMAIN]_ALL = "[domain].#";
}
```

### 3. Define Event DTO

Create event classes in the `event` package. These classes should be POJOs representing the message payload.

```java
package com.example.j2n.[service_name].messaging.[domain].event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class [Action]Event {
    private String id;
    // other fields...
}
```

### 4. Define RabbitMQ Configuration

Create `[Domain]EventConfig.java` in the `config` package to define Beans for Exchanges, Queues, and Bindings.

```java
package com.example.j2n.[service_name].messaging.[domain].config;

import com.example.j2n.[service_name].messaging.[domain].constant.[Domain]EventConstants;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class [Domain]EventConfig {

    @Bean
    public TopicExchange [domain]Exchange() {
        return new TopicExchange([Domain]EventConstants.EXCHANGE_[DOMAIN]);
    }

    @Bean
    public Queue [queueName]Queue() {
        return QueueBuilder.durable([Domain]EventConstants.QUEUE_[SERVICE]_[EVENT]).build();
    }

    @Bean
    public Binding [bindingName]Binding() {
        return BindingBuilder
                .bind([queueName]Queue())
                .to([domain]Exchange())
                .with([Domain]EventConstants.RK_[EVENT]);
    }
}
```

### 5. Implement Consumer

Create `[Domain]EventConsumer.java` or `[Domain]EventListener.java` in the `consumer` package. Use manual acknowledgement.

**Important**: The Consumer class must not contain business logic. It should only receive the message and delegate the processing to the appropriate Service class.

```java
package com.example.j2n.[service_name].messaging.[domain].consumer;

import com.example.j2n.[service_name].messaging.[domain].constant.[Domain]EventConstants;
import com.example.j2n.[service_name].messaging.[domain].event.[Action]Event;
import com.example.j2n.[service_name].service.[Some]Service;
import com.rabbitmq.client.Channel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class [Domain]EventConsumer {

    private final [Some]Service someService;

    @RabbitListener(queues = [Domain]EventConstants.QUEUE_[SERVICE]_[EVENT])
    public void on[Action]([Action]Event event, Channel channel, Message message) throws IOException {
        try {
            log.info("Received event: {}", event);

            // DELEGATE TO SERVICE - DO NOT PUT LOGIC HERE
            someService.handle[Action](event);

            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        } catch (Exception e) {
            log.error("Failed to process event: {}", e.getMessage(), e);
            // nack(deliveryTag, multiple, requeue)
            channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
        }
    }
}
```

### 6. Implement Publisher (If needed)

Create `[Domain]EventPublisher.java` in the `publisher` package to send messages.

```java
package com.example.j2n.[service_name].messaging.[domain].publisher;

import com.example.j2n.[service_name].messaging.[domain].constant.[Domain]EventConstants;
import com.example.j2n.[service_name].messaging.[domain].event.[Action]Event;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class [Domain]EventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public void publish[Action]([Action]Event event) {
        log.info("Publishing event: {}", event);
        rabbitTemplate.convertAndSend(
            [Domain]EventConstants.EXCHANGE_[DOMAIN],
            [Domain]EventConstants.RK_[EVENT],
            event
        );
    }
}
```

### 7. Triggering Event from Service

When triggering an event from a Service class, always extract the publishing logic into a dedicated private/protected method. This keeps the primary business logic clean and makes the code easier to maintain and test.

**Example**:

```java
@Transactional
public void updateSomething(Long id, Request request) {
    Entity entity = repository.findById(id).orElseThrow(...);
    String oldValue = entity.getValue();

    // Update entity
    updateEntity(entity, request);
    repository.save(entity);

    // CALL EXTRACTED METHOD
    publishSomethingChangedEvent(entity, oldValue);
}

private void publishSomethingChangedEvent(Entity entity, String oldValue) {
    if (!Objects.equals(oldValue, entity.getValue())) {
        eventPublisher.publishSomethingChanged(SomethingChangedEvent.builder()
                .id(entity.getId())
                .oldValue(oldValue)
                .newValue(entity.getValue())
                .build());
    }
}
```
