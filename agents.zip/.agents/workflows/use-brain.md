---
description: Quy trình thảo luận, brainstorm và lập kế hoạch (Planning)
---

# Quy trình Planning & Brainstorming (Không tạo code)

Hướng dẫn này giúp điều phối quá trình thảo luận, phân tích yêu cầu và lập kế hoạch các đầu việc cho một tính năng hoặc vấn đề mới trước khi bắt đầu viết code.

## 1. Xác định Mục tiêu & Yêu cầu (Goal Discovery)

Bắt đầu bằng việc làm rõ ý tưởng hoặc vấn đề cần giải quyết.

> [!IMPORTANT]
> **Hướng dẫn cho Agent:** Nếu yêu cầu của người dùng còn mơ hồ hoặc thiếu thông tin để có thể lập kế hoạch chi tiết, Agent **BẮT BUỘC** phải đặt các câu hỏi nhằm làm rõ trước khi chuyển sang bước brainstorming.

- **Mô tả bài toán:** Điều gì đang xảy ra? Hoặc tính năng mới mong muốn là gì?
- **User Story:** Ai là người dùng? Họ muốn làm gì và tại sao?
- **Ràng buộc:** Có giới hạn về thời gian, công nghệ, hoặc sự phụ thuộc vào các module khác không?

## 2. Brainstorming Ý tưởng & Giải pháp

Thảo luận về các cách tiếp cận khác nhau để giải quyết vấn đề.

- **Lựa chọn giải pháp:** Liệt kê ít nhất 2-3 phương án tiếp cận (nếu có).
- **Phân tích Ưu/Nhược điểm:** Đối với mỗi phương án, hãy đánh giá về độ phức tạp, khả năng mở rộng và hiệu suất.
- **Dữ liệu & Flow:** Phác thảo luồng đi của dữ liệu giữa các microservices hoặc các components.

## 3. Phân tích Phạm vi Ảnh hưởng (Impact Analysis)

Xác định những gì sẽ bị thay đổi trong hệ thống hiện tại.

- **Services:** Những microservice nào cần sửa đổi? (e.g., `order-srv`, `product-srv`, `bff-srv`).
- **Database:** Có cần thay đổi schema hay thêm bảng mới không?
- **API/Contracts:** Có thay đổi gRPC proto, GraphQL schema, hay RabbitMQ Events không?
- **Security:** Có ảnh hưởng đến phân quyền (RBAC) hay xác thực không?

## 4. Lập danh sách Đầu việc (Task Breakdown)

Chia nhỏ kế hoạch thành các task cụ thể, có thể thực hiện được.

- **Phase 1: Chuẩn bị & Database:** Tạo SQL scripts, cấu hình config.
- **Phase 2: Logic Backend:** Viết Service, Controller, Logic xử lý.
- **Phase 3: Giao tiếp & Integration:** RabbitMQ, gRPC, API Mapping.
- **Phase 4: Kiểm thử (Testing):** Unit Test, Integration Test.

## 5. Review & Chốt kế hoạch

Sau khi có danh sách task, hãy thực hiện kiểm tra cuối cùng.

- **Checklist:**
  - [ ] Kế hoạch đã bao quát hết các yêu cầu chưa?
  - [ ] Các task có bị phụ thuộc lẫn nhau theo thứ tự hợp lý không?
  - [ ] Có task nào quá lớn cần chia nhỏ thêm không?

---

> [!NOTE]
> Quy trình này tập trung hoàn toàn vào việc **tư duy và lập kế hoạch**. Đừng vội vàng tạo code trong giai đoạn này. Một kế hoạch tốt sẽ giúp việc code sau đó nhanh hơn và ít lỗi hơn.
